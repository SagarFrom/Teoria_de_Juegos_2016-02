#pragma once

namespace COMBINE(Log, __ID__) {
	void DXRelease();
};