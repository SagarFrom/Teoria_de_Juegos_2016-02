#include "IEntity.h"

#include <d3d11.h>

namespace FTJ
{

	IEntity::IEntity()
	{
	}
	IEntity::~IEntity()
	{
	}
}