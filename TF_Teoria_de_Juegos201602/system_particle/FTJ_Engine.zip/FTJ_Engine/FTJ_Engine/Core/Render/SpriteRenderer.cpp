#include "SpriteRenderer.h"

namespace FTJ
{

	CSpriteRenderer::CSpriteRenderer(CGameObject* _gameObject, eDepth _depth)
		: CRenderComponent(_gameObject, _depth)
	{
	}


	CSpriteRenderer::~CSpriteRenderer()
	{
	}

}